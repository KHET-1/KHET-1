#!/usr/bin/env python3
"""
StarFire CLI — LATTICE TEAM KHET-1
Default: Fully offline, zero-AI, court-safe
"""

import argparse
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from report.starfire import StarFireReport
from parser.pcap_parser import PcapParser
from evidence.sealer import EvidenceSealer
from councils.red import RedCouncil
from councils.blue import BlueCouncil
from councils.final_maker import FinalMaker


def main():
    parser = argparse.ArgumentParser(
        description="StarFire Forensic Analyzer — LATTICE TEAM KHET-1",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./starfire analyze capture.pcap
  ./starfire analyze *.pcapng --output ./report --local-llm
  ./starfire full /evidence/ --redact-internal
        """)

    parser.add_argument("command", choices=["analyze", "full", "seal", "verify"],
                       help="analyze: run analysis | full: analyze+report | seal: hash evidence | verify: check hashes")
    parser.add_argument("pcap_path", nargs="*", help="PCAP files or directories")
    parser.add_argument("--output", "-o", default="reports", help="Output directory")
    parser.add_argument("--offline", action="store_true", default=True,
                       help="Force offline zero-AI mode (default)")
    parser.add_argument("--local-llm", action="store_true",
                       help="Enable local Ollama narrative generation")
    parser.add_argument("--model", default="llama3.1:8b",
                       help="Ollama model (default: llama3.1:8b)")
    parser.add_argument("--redact-internal", action="store_true",
                       help="Auto-redact RFC1918 IP addresses")
    parser.add_argument("--redact-map", help="Path to custom redaction JSON map")
    parser.add_argument("--quick", action="store_true",
                       help="Quick scan (skip deep analysis)")
    parser.add_argument("--trace", action="store_true",
                       help="Enable crystalline trace: log every file touch, handoff, and Merkle inclusion")

    args = parser.parse_args()

    # Block all network
    os.environ['NO_PROXY'] = '*'
    os.environ['no_proxy'] = '*'

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    mode = "OFFLINE ZERO-AI" if not args.local_llm else "OFFLINE + LOCAL LLM"
    trace = args.trace

    print(f"")
    print(f"  STARFIRE — Light Forged in Evidence")
    print(f"  LATTICE TEAM — KHET-1")
    print(f"")
    print(f"  Mode:    {mode}")
    print(f"  Network: BLOCKED")
    if trace:
        print(f"  Trace:   ENABLED (crystalline data flow audit)")
    print()

    # Collect pcap files
    pcap_files = []
    for p in (args.pcap_path or ['.']):
        path = Path(p)
        if path.is_dir():
            pcap_files.extend(path.glob('*.pcap'))
            pcap_files.extend(path.glob('*.pcapng'))
        elif path.is_file():
            pcap_files.append(path)

    if not pcap_files and args.command in ('analyze', 'full'):
        print("No pcap files found. Provide file paths or a directory.")
        sys.exit(1)

    # ── SEAL ──
    if args.command == 'seal':
        sealer = EvidenceSealer()
        for f in pcap_files:
            item = sealer.ingest(str(f))
            print(f"  SEALED: {item.filename} | {item.sha256[:32]}...")
        root = sealer.seal()
        manifest = sealer.save_manifest(str(output_dir / 'chain_of_custody.json'))
        print(f"\nMerkle Root: {root}")
        print(f"Manifest: {output_dir / 'chain_of_custody.json'}")
        return

    # ── VERIFY ──
    if args.command == 'verify':
        import json
        custody_path = output_dir / 'chain_of_custody.json'
        if not custody_path.exists():
            print("No chain_of_custody.json found. Run 'seal' first.")
            sys.exit(1)
        custody = json.loads(custody_path.read_text())
        sealer = EvidenceSealer()
        for item in custody.get('items', []):
            sealer.ingest(item['filepath'])
        results = sealer.verify_all()
        all_ok = all(results.values())
        for name, ok in results.items():
            status = "VERIFIED" if ok else "FAILED"
            print(f"  {name}: {status}")
        print(f"\nIntegrity: {'ALL VERIFIED' if all_ok else 'INTEGRITY FAILURE DETECTED'}")
        return

    # ── ANALYZE / FULL ──
    print(f"Evidence: {len(pcap_files)} file(s)")

    # Phase 0: Seal evidence
    sealer = EvidenceSealer()
    for f in pcap_files:
        item = sealer.ingest(str(f))
        print(f"  SEALED: {item.filename} | {item.sha256[:32]}...")
        if trace:
            print(f"    [TRACE] File: {item.filepath}")
            print(f"    [TRACE] Size: {item.size_bytes:,} bytes")
            print(f"    [TRACE] SHA-256: {item.sha256}")
            print(f"    [TRACE] MD5: {item.md5}")
            print(f"    [TRACE] Merkle leaf added: evidence:{item.filename}")
    sealer.seal()
    if trace:
        print(f"  [TRACE] Evidence Merkle root: {sealer.merkle.get_root()}")
    print()

    # Phase 1: Parse
    print("Parsing packets...")
    pcap_parser = PcapParser()
    df = pcap_parser.parse_multiple([str(f) for f in pcap_files])
    print(f"  {len(df)} packets parsed")
    if trace:
        print(f"  [TRACE] DataFrame shape: {df.shape}")
        print(f"  [TRACE] Columns: {list(df.columns)}")
        print(f"  [TRACE] Time range: {df['time'].min()} → {df['time'].max()}")
        print(f"  [TRACE] Unique src IPs: {df['src_ip'].nunique()}")
        print(f"  [TRACE] Unique dst IPs: {df['dst_ip'].nunique()}")
        print(f"  [TRACE] Handoff → councils (DataFrame with {len(df)} rows)")
    print()

    if len(df) == 0:
        print("No packets found.")
        sys.exit(1)

    # Detect local IPs — use only the TOP source (the machine that captured)
    # Including multiple top sources causes LAN peers to be excluded from analysis
    local_ips = set()
    local_ips.add('127.0.0.1')
    top_src = df['src_ip'].value_counts()
    if len(top_src) > 0:
        primary_src = top_src.index[0]
        local_ips.add(primary_src)
    local_ips.discard(None)
    print(f"  Local IP (source): {local_ips - {'127.0.0.1'}}")
    print()

    # Phase 2: Councils
    if not args.quick:
        print("Running Red Council (attribution)...")
        red = RedCouncil()
        red_findings = red.analyze(df, local_ips)
        print(f"  {len(red_findings)} findings")
        if trace:
            for f in red_findings:
                print(f"  [TRACE] RED {f.id}: {f.category} → {f.target} (conf={f.confidence:.2f})")

        print("Running Blue Council (innocence)...")
        blue = BlueCouncil()
        blue_findings = blue.analyze(df, local_ips)
        print(f"  {len(blue_findings)} findings")
        if trace:
            for f in blue_findings:
                print(f"  [TRACE] BLUE {f.id}: {f.category} → {f.target} (conf={f.confidence:.2f})")

        print("Final Maker resolving...")
        maker = FinalMaker()
        verdicts, debate_log = maker.resolve(red_findings, blue_findings)
        alignment = maker.get_alignment()
        print(f"  {len(debate_log)} debates | Alignment: {alignment:.0%}")
        if trace:
            for d in debate_log:
                print(f"  [TRACE] DEBATE: {d['red_id']} vs {d['blue_id']} → {d['resolution']}")
                print(f"           Red conf={d['red_confidence']:.2f} | Blue conf={d['blue_confidence']:.2f}")
        print()
    else:
        red_findings = []
        blue_findings = []
        verdicts = []
        debate_log = []
        alignment = 1.0

    # Build results dict
    protocols = df['protocol'].value_counts().to_dict() if 'protocol' in df.columns else {}
    duration = (df['time'].max() - df['time'].min()).total_seconds() if len(df) > 1 else 0

    # Determine classification
    classification = "UNDETERMINED"
    confidence = 50
    if verdicts:
        red_wins = sum(1 for v in verdicts if v.resolution == "RED_PREVAILS")
        blue_wins = sum(1 for v in verdicts if v.resolution == "BLUE_PREVAILS")
        if blue_wins > red_wins:
            classification = "LIKELY BENIGN"
            confidence = 85
        elif red_wins > blue_wins:
            classification = "SUSPICIOUS"
            confidence = 70

    results = {
        "final_classification": classification,
        "confidence": confidence,
        "council_alignment": f"{alignment:.0%}",
        "verdict": f"{classification} (confidence {confidence}%)",
        "total_packets": len(df),
        "total_bytes": int(df['length'].sum()) if 'length' in df.columns else 0,
        "duration": f"{duration:.1f} seconds",
        "first_packet": str(df['time'].min()) if 'time' in df.columns else "",
        "last_packet": str(df['time'].max()) if 'time' in df.columns else "",
        "protocols": protocols,
        "key_findings": [
            {"title": f.hypothesis, "detail": f.evidence}
            for f in (red_findings + [bf for bf in blue_findings if bf.confidence > 0.8])[:6]
        ],
        "castles": [
            {"name": v.red_finding.hypothesis[:60], "severity": v.red_finding.severity,
             "conclusion": v.reasoning, "confidence": v.winning_confidence,
             "council_origin": "merged" if v.resolution != "UNCHALLENGED_RED" else "red"}
            for v in verdicts
        ] if verdicts else [],
        "debate": {"debate_log": debate_log},
        "drip_trace": [],
        "payloads": [],
        "processes": {},
        "residual_risks": []
    }

    # Phase 3: Generate report
    if args.command == 'full' or args.command == 'analyze':
        print("Generating StarFire report...")
        report = StarFireReport(output_dir=str(output_dir))
        custody_manifest = sealer.to_manifest()
        report.generate(results, custody_manifest=custody_manifest, use_local_llm=args.local_llm)
        sealer.save_manifest(str(output_dir / 'chain_of_custody.json'))
        print()
        print(f"Analysis complete.")
        print(f"  Report: {output_dir}/starfire_report.html")
        print(f"  JSON:   {output_dir}/starfire_report.json")
        print(f"  Chain:  {output_dir}/chain_of_custody.json")
        print(f"  Merkle: {output_dir}/merkle_manifest.json")


if __name__ == "__main__":
    main()
